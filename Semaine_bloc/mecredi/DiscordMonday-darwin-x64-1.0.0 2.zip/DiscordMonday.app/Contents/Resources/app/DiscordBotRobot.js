// node BotController.js

// • Multiple de 3, ou qui contient 3 – “bizz.”
// • Multiple de 7, ou qui contient 7 – “buzz.”
// • Multiple de 9, ou qui contient 9 – “bop.”
// • Combinations de 3 et 7 (par ex 21) - “bizzBuzz.”
// • Combinations de 3 et 9 (par ex 9) - “bizzBop.”
// • Combinations de 7 et 9 result (par ex 49) - “buzzBop.”
// • Combinations de 3, 7, et 9 (par ex 27) - “bizBuzzBop.” (dans cet ordre)

const { Client, MessageEmbed } = require("discord.js");

class DiscordBotRobot {
  constructor(token, win) {
    this.win = win;
    console.log("Bot started");
    this.client = new Client();
    //document.addEventListener("click", functionquandonclick)
    this.client.on("ready", this.onReady.bind(this));
    this.client.on("message", this.onMessage.bind(this));
    this.client.login(token);
  }
  onReady() {
    console.log("Bot is ready");
  }

  onMessage(message) {
    console.log(message);
    this.win.webContents.send("messageDiscord", message.content);

    // const receivedEmbed = message.embeds[0];

    // if (receivedEmbed) {
    //   this.win.webContents.send("embedDiscord", receivedEmbed);
    // } else {
    //   this.win.webContents.send("messageDiscord", message.content);
    // }

    // // console.log(message.content);
    // // this.win.webContents.send("messageDiscord", message.content);
  }
}

module.exports = { DiscordBotRobot };
