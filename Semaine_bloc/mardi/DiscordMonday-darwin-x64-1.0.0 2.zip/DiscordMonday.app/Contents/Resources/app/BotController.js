const DiscordBot = require("./DiscordBot.js").DiscordBot;
new DiscordBot("ODE1ODYyODIyNjM3Nzk3Mzg4.YDyldg.7aLyKZLMoJiSpk4etYc_gMD44xM");
