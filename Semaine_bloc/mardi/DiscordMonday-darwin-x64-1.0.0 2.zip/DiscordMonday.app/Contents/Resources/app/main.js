const { app, BrowserWindow } = require("electron");
const { DISCORD_TOKEN } = require("./config");

let win = null;

function createWindow() {
  win = new BrowserWindow({
    //on peut regler plein de trucs, opacité de la fenêtre et tout
    width: 1024,
    height: 768,
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false,
    },
  });

  win.loadFile("index.html");
  // win.setFullScreen(true);
  // win.maximize();
}

function initBot() {
  const DiscordBot = require("./DiscordBot.js").DiscordBot;
  new DiscordBot(
    "ODE1ODYyODIyNjM3Nzk3Mzg4.YDyldg.kt48FRMAfskKJMm3WWZPgROnXIc",
    win
  );
  // const { DiscordBotRobot } = require("./DiscordBotRobot");
  // new DiscordBotRobot(DISCORD_TOKEN, win);
}
app.allowRendererProcessReuse = false;
app.whenReady().then(createWindow).then(initBot);
app.on("activate", () => {
  if (BrowserWindow.getAllWindows().length === 0) {
    createWindow();
  }
});

function openWindow() {
  ipcRenderer.send("asynchronous-message", "createNewWindow");
}

var ipcMain = require("electron").ipcMain;
ipcMain.on("asynchronous-message", function (evt, message) {
  if (message == "createNewWindow") {
    console.log("lol");
    openWindow();
    // Message received.
    // Create new window here.
  }
});
