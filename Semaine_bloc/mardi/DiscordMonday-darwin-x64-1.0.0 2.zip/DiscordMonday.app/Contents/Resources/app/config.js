module.exports = {
  DISCORD_TOKEN: "ODE1ODYyODIyNjM3Nzk3Mzg4.YDyldg.kt48FRMAfskKJMm3WWZPgROnXIc",
};
