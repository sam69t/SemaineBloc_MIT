const { ipcRenderer } = require("electron");
const robot = require("robotjs");

class App {
  constructor() {
    console.log("LOG depuis page html");
    this.initListeners();

    for (let i = 0; i < 3280; i++) {
      const button = document.createElement("button");
      button.textContent = "";
      document.body.appendChild(button);
      button.addEventListener("mouseenter", () => {
        button.classList.toggle("activated");
      });
      button.addEventListener("click", () => {
        button.classList.add("blur");
      });
    }

    const screenSize = robot.getScreenSize();
    this.height = screenSize.height;
    this.width = screenSize.width;
  }

  initListeners() {
    ipcRenderer.on("messageDiscord", this.onMessage.bind(this));
  }

  draw() {
    //while (counter < 2) {
    this.angle += 0.05;
    const x = this.width / 2 + Math.cos(this.angle) * this.radius;
    const y = this.height / 2 + Math.sin(this.angle) * this.radius;
    robot.moveMouse(x, y);

    if (this.angle < Math.PI * 5) {
      requestAnimationFrame(this.draw.bind(this));
    }
    //}
  }

  onMessage(event, message) {
    if (message === "H") {
      robot.setMouseDelay(3);
      this.radius = this.height / 5 - 10;
      this.angle = 0;

      this.draw();
    }
    if (message === "G") {
      let bouton = document.querySelector("button");
      bouton.style.backgroundColor = "blue;";

      robot.setMouseDelay(3);
      this.radius = this.height / 3 - 10;
      this.angle = 0;

      this.draw();
    }
  }
}

window.onload = () => {
  new App();
};
