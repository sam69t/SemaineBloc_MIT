const { ipcRenderer } = require("electron");

class App {
  constructor() {
    console.log("LOG depuis la page HTML");
    this.initListeners();
  }

  initListeners() {
    ipcRenderer.on("messageDiscord", this.onMessage.bind(this));
    ipcRenderer.on("embedDiscord", this.onEmbed.bind(this));
  }
  onEmbed(event, message) {
    // console.log(message);
    // document.body.innerHTML = message.description;
    // if ((message.description = "bleu")) {
    //   document.body.style.backgroundColor = "white";
    // }
  }
  onMessage(event, message) {
    console.log(message);
    if (message === "P") {
      setTimeout(() => {
        console.log("hey");
        let audiosucess = new Audio("./NOTIF.mp3");
        audiosucess.play();

        let text1 = document.querySelector("#text1"); // ne correspond à rien
        text1.classList.remove("hide");
      }, 200);

      setTimeout(() => {
        let audiosucess = new Audio("./NOTIF.mp3");
        audiosucess.play();

        text1.classList.add("hide");
        let text2 = document.querySelector("#text2"); // ne correspond à rien
        text2.classList.remove("hide");
      }, 1400);
      setTimeout(() => {
        let audiosucess = new Audio("./NOTIF.mp3");
        audiosucess.play();

        text2.classList.add("hide");
        let text3 = document.querySelector("#text3"); // ne correspond à rien
        text3.classList.remove("hide");
      }, 3000);
      setTimeout(() => {
        let audiosucess = new Audio("./NOTIF.mp3");
        audiosucess.play();
        text3.classList.add("hide");
        let text4 = document.querySelector("#text4"); // ne correspond à rien
        text4.classList.remove("hide");
      }, 3800);
      setTimeout(() => {
        let audiosucess = new Audio("./NOTIF.mp3");
        audiosucess.play();
        let text5 = document.querySelector("#text5"); // ne correspond à rien
        text5.classList.remove("hide");
      }, 4500);
      setTimeout(() => {
        let audiosucess = new Audio("./NOTIF.mp3");
        audiosucess.play();
        let text6 = document.querySelector("#text6"); // ne correspond à rien
        text6.classList.remove("hide");
      }, 5200);
    }

    if (message === "F") {
      text4.classList.add("select");

      setTimeout(() => {
        let audiosucess = new Audio("./NOTIF.mp3");
        audiosucess.play();
        text4.classList.add("hide");
        text5.classList.add("hide");
        text6.classList.add("hide");
      }, 1000);
      setTimeout(() => {
        let audiosucess = new Audio("./NOTIF.mp3");
        audiosucess.play();
        let text7 = document.querySelector("#text7");
        text7.classList.remove("hide");
      }, 1200);
      setTimeout(() => {
        let audiosucess2 = new Audio("./NOTIF2.mp3");
        audiosucess2.play();

        let text7 = document.querySelector("#text7");

        text7.classList.add("hide");
        let text8 = document.querySelector("#text8"); // ne correspond à rien
        text8.classList.remove("hide");
        text8.classList.add("select2");
      }, 3500);

      setTimeout(() => {
        let audiosucess = new Audio("./NOTIF.mp3");
        audiosucess.play();
        let text8 = document.querySelector("#text8"); // ne correspond à rien
        text8.classList.add("hide");

        let text9 = document.querySelector("#text9"); // ne correspond à rien
        text9.classList.remove("hide");
      }, 7400);
      setTimeout(() => {
        let audiosucess = new Audio("./NOTIF.mp3");
        audiosucess.play();
        let text9 = document.querySelector("#text9"); // ne correspond à rien

        text9.classList.add("hide");
      }, 8200);
      setTimeout(() => {
        let audiosucess = new Audio("./NOTIF.mp3");
        audiosucess.play();
        let text10 = document.querySelector("#text10"); // ne correspond à rien
        text10.classList.remove("hide");
      }, 10200);
      setTimeout(() => {
        let audiosucess = new Audio("./NOTIF.mp3");
        audiosucess.play();
        let text11 = document.querySelector("#text11"); // ne correspond à rien
        text11.classList.remove("hide");
      }, 11700);
      setTimeout(() => {
        let audiosucess = new Audio("./NOTIF.mp3");
        audiosucess.play();
        let text12 = document.querySelector("#text12"); // ne correspond à rien
        text12.classList.remove("hide");
      }, 13300);
      setTimeout(() => {
        let audiosucess = new Audio("./NOTIF.mp3");
        audiosucess.play();
        let text13 = document.querySelector("#text13"); // ne correspond à rien
        text13.classList.remove("hide");
      }, 14800);
      setTimeout(() => {
        let audiosucess = new Audio("./NOTIF.mp3");
        audiosucess.play();
        let text14 = document.querySelector("#text14"); // ne correspond à rien
        text14.classList.remove("hide");
      }, 16100);
      setTimeout(() => {
        let audiosucess3 = new Audio("./NOTIF3.mp3");
        audiosucess3.play();
        let pomme = document.querySelector("#pimelo"); // ne correspond à rien
        pomme.classList.remove("hide");

        let text10 = document.querySelector("#text10"); // ne correspond à rien
        text10.classList.add("hide");
        let text11 = document.querySelector("#text11"); // ne correspond à rien
        text11.classList.add("hide");
        let text12 = document.querySelector("#text12"); // ne correspond à rien
        text12.classList.add("hide");
        let text14 = document.querySelector("#text14"); // ne correspond à rien
        text14.classList.add("hide");
        let text13 = document.querySelector("#text13"); // ne correspond à rien
        text13.classList.add("hide");
        let text15 = document.querySelector("#text15"); // ne correspond à rien
        text15.classList.remove("hide");
      }, 18000);
    }
  }
}

//   // text1.textContent = message;
// } else {
//   // text1.classList.add("hide");
// }
// if (this.receivedEmbed === "choix") {
//   setTimeout(() => {
//     console.log("hey");
//     let text2 = document.querySelector("#text2"); // ne correspond à rien
//     text2.classList.remove("hide");
//   }, 1500);

// text1.textContent = message;

// document.getElementById("surmenu").style.backgroundColor = "transparent";

// document.body.innerHTML = `TEST D'ECRITURE DEPUIS APP.JS`

// document.body.textContent = message;
// if ((message = "bleu")) {
//   document.body.style.backgroundColor = "white";
//   document.body.style.backgroundColor = "white";
//   document.body.classList.add(".titre");
// }

window.onload = () => {
  new App();
};
